# FitZone Fitness Club | Premium Gym & Fitness Center

FitZone Fitness Club is a premium, luxury fitness center static website designed for modern web browsers. Built as a high-performance, portfolio-quality internship project, it showcases frontend excellence across responsive grids, clean accessibility hooks (WCAG AA), SEO parameters, visual typography, and custom interactive widgets.

---

## 🔗 Live Demo & Screenshots

### Live Demo
👉 **[Launch FitZone Live Portal](https://fitzoneclub.netlify.app)** *(Link placeholder)*

### Interface Previews
- **Desktop Home (Dark Mode)**: `[Insert Desktop Home Screenshot Here]`
- **Mobile Responsive Navigation**: `[Insert Mobile Nav Screenshot Here]`
- **Interactive BMI Sweep Gauge**: `[Insert BMI Gauge Screenshot Here]`

---

## ✨ Features Checklist
- **Light & Dark Themes**: Smooth color scheme switching persisted in `localStorage`.
- **Dynamic BMI Calculator**: Metric & Imperial calculator sweeping a 180° visual gauge indicator.
- **Weekly Schedule Filtering**: Highlight/dim schedule blocks based on category pills (HIIT, Strength, Yoga).
- **Custom Gallery Lightbox**: Keyboard-controlled overlay viewer (Escape close, Arrow Left/Right cycling).
- **Achievements Counter**: IntersectionObserver-triggered animated count-up numbers.
- **AOS Animations**: Smooth scroll-triggered visual entrance effects.
- **Accessibility (WCAG AA)**: Semantic elements, explicit label markers, keyboard focus indicators, and custom ARIA labels.
- **SEO Ready**: Complete meta descriptions, Open Graph parameters, sitemap, and robots indexes.

---

## 🛠️ Technologies Used
- **Languages**: HTML5, CSS3, ES6 JavaScript
- **Framework**: Bootstrap 5.3 (CSS & JS components)
- **Icons**: Font Awesome v6 (via CDN)
- **Scroll Animations**: AOS Library (via CDN)

---

## 📂 File Directory Structure
```
/ (Root)
├── index.html          (Home Page - Hero Slider, Stats, Testimonials, FAQ)
├── about.html          (About Page - legacy narrative, values, spaces layout)
├── trainers.html       (Trainers Page - trainer bio cards, credentials, certs)
├── classes.html        (Classes Schedule - responsive schedule, category filters)
├── membership.html     (Membership Plans - plan selector, feature comparison matrix)
├── bmi.html            (BMI Calculator - metrics converter, rotation progress gauge)
├── gallery.html        (Photo Gallery - category tabs, custom image lightbox)
├── contact.html        (Contact Page - FormSubmit handler, Google maps, WhatsApp)
├── 404.html            (Custom Branded 404 Page)
├── robots.txt          (Crawler directions)
├── sitemap.xml         (Search engine priority page mapping)
├── .gitignore          (Untracked file settings)
├── css/
│   └── style.css       (Core variables, typography, layouts, animations)
├── js/
│   ├── main.js         (Theme synchronizer, counter observer, scroll throttlers, toasts)
│   ├── bmi.js          (Unit calculations, sweep gauge math, tips)
│   └── lightbox.js     (Masonry gallery filters, lightbox arrow handlers)
└── images/
    ├── logo.svg        (Universal brand vector SVG logo)
    ├── hero-bg.png     (Generated luxury gym background)
    ├── trainer-1.png   (Male athletic coach photograph)
    └── trainer-2.png   (Female fitness coach photograph)
```

---

## 💻 Local Installation Setup
To run this project locally without any dependencies:
1. Clone this repository:
   ```bash
   git clone https://github.com/your-username/fitzone-fitness-club.git
   ```
2. Open the directory:
   ```bash
   cd fitzone-fitness-club
   ```
3. Open `index.html` in your favorite web browser or spin up a simple local server:
   ```bash
   # Python 3
   python -m http.server 8000
   
   # Node.js (npx)
   npx http-server -p 8000
   ```
4. Access the site via **`http://localhost:8000`**.

---

## 🚀 Deployment Instructions

### Netlify (Drag & Drop)
1. Zip the folder containing all project files (ensuring `index.html` is at the root).
2. Drag and drop the `.zip` file into [Netlify Drop](https://app.netlify.com/drop).
3. The site is live instantly!

### GitHub Pages
1. Push this directory to your public GitHub repository.
2. In the repository settings, go to the **Pages** menu.
3. Select the **main** branch as the build source and directory to `/root`.
4. Click **Save** and wait for the action build.

### Vercel (CLI)
1. Install Vercel CLI: `npm i -g vercel`.
2. Run `vercel` in the project root directory.
3. Follow prompts to deploy the static folder.

---

## ✍️ Author
- **Name**: Krishna
- **GitHub**: [@Krishna-Jonnala](https://github.com/Krishna-Jonnala)
- **LinkedIn**: [Krishna Jonnala](https://linkedin.com/in/krishna-jonnala)

