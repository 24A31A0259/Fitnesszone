/*
========================================================================
   FITZONE FITNESS CLUB - MAIN JS (PRODUCTION GRADE)
   Description: Null-safe site behaviors, counters, themes, and interactions.
   Author: Krishna Jonnala
========================================================================
*/

document.addEventListener('DOMContentLoaded', () => {
    // --- 1. PRELOADER HANDLER ---
    const preloader = document.getElementById('preloader');
    if (preloader) {
        window.addEventListener('load', () => {
            preloader.style.opacity = '0';
            setTimeout(() => {
                preloader.style.visibility = 'hidden';
            }, 500); // match transition slow
        });
        
        // Safety timeout fallback
        setTimeout(() => {
            if (preloader.style.visibility !== 'hidden') {
                preloader.style.opacity = '0';
                preloader.style.visibility = 'hidden';
            }
        }, 2500);
    }

    // --- 2. DARK/LIGHT THEME TOGGLE & SYNC ---
    const themeToggleBtn = document.getElementById('theme-toggle');
    const themeToggleMobileBtn = document.getElementById('theme-toggle-mobile');
    const currentTheme = localStorage.getItem('theme') || 'dark';

    // Apply initial theme
    document.documentElement.setAttribute('data-theme', currentTheme);
    syncThemeIcons(currentTheme);

    function toggleTheme() {
        const theme = document.documentElement.getAttribute('data-theme');
        const newTheme = theme === 'dark' ? 'light' : 'dark';
        
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        syncThemeIcons(newTheme);
    }

    if (themeToggleBtn) {
        themeToggleBtn.addEventListener('click', toggleTheme);
    }
    if (themeToggleMobileBtn) {
        themeToggleMobileBtn.addEventListener('click', toggleTheme);
    }

    function syncThemeIcons(theme) {
        const iconDesktop = themeToggleBtn ? themeToggleBtn.querySelector('i') : null;
        const iconMobile = themeToggleMobileBtn ? themeToggleMobileBtn.querySelector('i') : null;
        const className = theme === 'light' ? 'fa-solid fa-moon' : 'fa-solid fa-sun';
        
        if (iconDesktop) iconDesktop.className = className;
        if (iconMobile) iconMobile.className = className;
    }

    // --- 3. STICKY NAVBAR, SCROLL PROGRESS & BACK-TO-TOP ---
    const navbar = document.querySelector('.navbar-custom');
    const scrollProgress = document.getElementById('scroll-progress');
    const backToTop = document.getElementById('back-to-top');

    // Scroll throttle to improve performance
    let scrollTimeout = null;
    window.addEventListener('scroll', () => {
        if (scrollTimeout) return;
        
        scrollTimeout = setTimeout(() => {
            const scrollTop = window.scrollY;
            const docHeight = document.documentElement.scrollHeight - window.innerHeight;
            
            // Sticky Nav
            if (navbar) {
                if (scrollTop > 50) {
                    navbar.classList.add('navbar-scrolled');
                } else {
                    navbar.classList.remove('navbar-scrolled');
                }
            }

            // Scroll Progress
            if (scrollProgress && docHeight > 0) {
                const scrollPercent = (scrollTop / docHeight) * 100;
                scrollProgress.style.width = scrollPercent + '%';
            }

            // Back to Top Visibility
            if (backToTop) {
                if (scrollTop > 300) {
                    backToTop.classList.add('show');
                } else {
                    backToTop.classList.remove('show');
                }
            }
            
            scrollTimeout = null;
        }, 15);
    });

    // --- 4. BACK TO TOP CLICK HANDLER ---
    if (backToTop) {
        backToTop.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    // --- 5. ACTIVE NAVBAR LINK HIGHLIGHTER ---
    const currentPath = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('.nav-link-custom');
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (href === currentPath) {
            link.classList.add('active');
            link.setAttribute('aria-current', 'page');
        } else {
            link.classList.remove('active');
            link.removeAttribute('aria-current');
        }
    });

    // --- 6. STATS COUNTER ANIMATION ---
    const statsSection = document.querySelector('.stats-section');
    const counters = document.querySelectorAll('.stat-number');
    
    if (statsSection && counters.length > 0) {
        const speed = 200;
        let animated = false;

        const countUp = () => {
            counters.forEach(counter => {
                const target = +counter.getAttribute('data-target');
                const increment = target / speed;

                const updateCount = () => {
                    const current = +counter.innerText;
                    if (current < target) {
                        counter.innerText = Math.ceil(current + increment);
                        setTimeout(updateCount, 10);
                    } else {
                        counter.innerText = target;
                    }
                };

                updateCount();
            });
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !animated) {
                    countUp();
                    animated = true;
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.3 });

        observer.observe(statsSection);
    }

    // --- 7. FAQ ACCORDION TOGGLE ---
    const accordionItems = document.querySelectorAll('.accordion-item-custom');
    accordionItems.forEach(item => {
        const header = item.querySelector('.accordion-header-custom');
        if (header) {
            header.addEventListener('click', () => {
                const isActive = item.classList.contains('active');
                
                // Close all items
                accordionItems.forEach(i => i.classList.remove('active'));
                
                // Toggle clicked item
                if (!isActive) {
                    item.classList.add('active');
                }
            });
            
            // Allow keyboard activation (Space/Enter)
            header.setAttribute('tabindex', '0');
            header.setAttribute('role', 'button');
            header.addEventListener('keydown', (e) => {
                if (e.key === ' ' || e.key === 'Enter') {
                    e.preventDefault();
                    header.click();
                }
            });
        }
    });

    // --- 8. NEWSLETTER SIGNUP FORM ---
    const newsletterForm = document.getElementById('newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const emailInput = newsletterForm.querySelector('input[type="email"]');
            if (emailInput && emailInput.value.trim() !== '') {
                showToast('Thank you for subscribing to our newsletter! Stay fit.');
                emailInput.value = '';
            }
        });
    }

    // --- 9. TOAST NOTIFICATION UTILITY ---
    function showToast(message) {
        let toast = document.getElementById('custom-toast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'custom-toast';
            toast.className = 'toast-custom';
            document.body.appendChild(toast);
        }
        
        toast.innerText = message;
        toast.classList.add('show');
        
        setTimeout(() => {
            toast.classList.remove('show');
        }, 4000);
    }

    // Expose showToast globally
    window.showToast = showToast;
});
