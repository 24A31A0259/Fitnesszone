/*
========================================================================
   FITZONE FITNESS CLUB - LIGHTBOX JS (PRODUCTION GRADE)
   Description: Gallery category filter and responsive lightbox modal.
   Author: Krishna Jonnala
========================================================================
*/

document.addEventListener('DOMContentLoaded', () => {
    // --- 1. GALLERY FILTER SYSTEM ---
    const filterButtons = document.querySelectorAll('.gallery-filter-btn');
    const galleryItems = document.querySelectorAll('.gallery-item-col');

    if (filterButtons.length > 0 && galleryItems.length > 0) {
        filterButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                
                // Toggle active class
                filterButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');

                const filterValue = button.getAttribute('data-filter');

                galleryItems.forEach(item => {
                    const category = item.getAttribute('data-category');
                    if (filterValue === 'all' || category === filterValue) {
                        item.style.display = 'block';
                        setTimeout(() => {
                            item.style.opacity = '1';
                            item.style.transform = 'scale(1)';
                        }, 50);
                    } else {
                        item.style.opacity = '0';
                        item.style.transform = 'scale(0.85)';
                        setTimeout(() => {
                            item.style.display = 'none';
                        }, 300);
                    }
                });
            });
        });
    }

    // --- 2. LIGHTBOX VIEWER SYSTEM ---
    const lightbox = document.getElementById('lightbox');
    const lightboxImg = document.getElementById('lightbox-img');
    const lightboxCaption = document.getElementById('lightbox-caption');
    const closeBtn = document.getElementById('lightbox-close');
    const prevBtn = document.getElementById('lightbox-prev');
    const nextBtn = document.getElementById('lightbox-next');
    const galleryTriggers = document.querySelectorAll('.gallery-item');

    // Exit early if page doesn't have a lightbox
    if (!lightbox || !lightboxImg) return;

    let currentIndex = 0;
    let activeList = [];

    function updateActiveList() {
        // Find visible gallery items based on filters
        activeList = Array.from(galleryTriggers).filter(item => {
            const parent = item.closest('.gallery-item-col');
            return parent && parent.style.display !== 'none';
        });
    }

    function showImage(index) {
        if (activeList.length === 0) return;
        
        if (index < 0) {
            currentIndex = activeList.length - 1;
        } else if (index >= activeList.length) {
            currentIndex = 0;
        } else {
            currentIndex = index;
        }

        const trigger = activeList[currentIndex];
        if (!trigger) return;

        const img = trigger.querySelector('img');
        if (!img) return;

        const title = trigger.getAttribute('data-title') || img.getAttribute('alt') || 'FitZone Club Gallery';
        
        lightboxImg.src = img.src;
        lightboxImg.alt = img.alt || 'Gallery Zoom View';
        if (lightboxCaption) lightboxCaption.innerText = title;
    }

    // Open Lightbox
    galleryTriggers.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            updateActiveList();
            
            currentIndex = activeList.indexOf(item);
            if (currentIndex === -1) {
                // fallback
                activeList = Array.from(galleryTriggers);
                currentIndex = activeList.indexOf(item);
            }

            showImage(currentIndex);
            
            lightbox.classList.add('show');
            document.body.style.overflow = 'hidden';
            
            // Set focus on close button for accessibility
            if (closeBtn) closeBtn.focus();
        });
    });

    // Close Lightbox
    function closeLightbox() {
        lightbox.classList.remove('show');
        document.body.style.overflow = '';
    }

    if (closeBtn) {
        closeBtn.addEventListener('click', (e) => {
            e.preventDefault();
            closeLightbox();
        });
    }

    // Backdrop click close
    lightbox.addEventListener('click', (e) => {
        if (e.target === lightbox || e.target.classList.contains('lightbox-content')) {
            closeLightbox();
        }
    });

    // Navigation Controls
    if (prevBtn) {
        prevBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            showImage(currentIndex - 1);
        });
    }

    if (nextBtn) {
        nextBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            showImage(currentIndex + 1);
        });
    }

    // Keyboard controls
    document.addEventListener('keydown', (e) => {
        if (lightbox.classList.contains('show')) {
            if (e.key === 'Escape') {
                closeLightbox();
            } else if (e.key === 'ArrowLeft') {
                showImage(currentIndex - 1);
            } else if (e.key === 'ArrowRight') {
                showImage(currentIndex + 1);
            }
        }
    });
});
