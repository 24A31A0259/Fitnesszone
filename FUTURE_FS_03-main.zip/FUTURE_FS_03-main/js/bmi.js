/*
========================================================================
   FITZONE FITNESS CLUB - BMI CALCULATOR JS (PRODUCTION GRADE)
   Description: Null-safe, validated BMI metric/imperial sweep calculators.
   Author: Krishna Jonnala
========================================================================
*/

document.addEventListener('DOMContentLoaded', () => {
    // --- Selectors ---
    const metricTab = document.getElementById('tab-metric');
    const imperialTab = document.getElementById('tab-imperial');
    const metricInputs = document.getElementById('inputs-metric');
    const imperialInputs = document.getElementById('inputs-imperial');
    
    const weightKg = document.getElementById('weight-kg');
    const heightCm = document.getElementById('height-cm');
    const weightLbs = document.getElementById('weight-lbs');
    const heightFt = document.getElementById('height-ft');
    const heightIn = document.getElementById('height-in');
    
    const calculateBtn = document.getElementById('calculate-bmi-btn');
    
    const bmiValueEl = document.getElementById('bmi-val');
    const bmiBadgeEl = document.getElementById('bmi-badge');
    const bmiTipEl = document.getElementById('bmi-tip');
    const bmiGaugeFill = document.getElementById('bmi-gauge-fill');
    
    let activeUnit = 'metric';

    // Guard to prevent errors if elements do not exist on the current page
    if (!calculateBtn) return;

    // --- Tab Toggles ---
    if (metricTab && imperialTab && metricInputs && imperialInputs) {
        metricTab.addEventListener('click', (e) => {
            e.preventDefault();
            activeUnit = 'metric';
            metricTab.classList.add('active');
            imperialTab.classList.remove('active');
            metricInputs.style.display = 'block';
            imperialInputs.style.display = 'none';
        });

        imperialTab.addEventListener('click', (e) => {
            e.preventDefault();
            activeUnit = 'imperial';
            imperialTab.classList.add('active');
            metricTab.classList.remove('active');
            metricInputs.style.display = 'none';
            imperialInputs.style.display = 'block';
        });
    }

    // --- Calculator Handler ---
    calculateBtn.addEventListener('click', (e) => {
        e.preventDefault();
        let bmi = 0;
        let weight = 0;
        let height = 0;

        if (activeUnit === 'metric') {
            const kg = parseFloat(weightKg.value);
            const cm = parseFloat(heightCm.value);

            // Validations
            if (isNaN(kg) || kg < 20 || kg > 400 || isNaN(cm) || cm < 80 || cm > 280) {
                showValidationError('Please enter realistic values: Weight 20-400 kg, Height 80-280 cm.');
                return;
            }
            
            weight = kg;
            height = cm / 100;
            bmi = weight / (height * height);

        } else {
            const lbs = parseFloat(weightLbs.value);
            const ft = parseFloat(heightFt.value);
            const inches = parseFloat(heightIn.value) || 0;

            // Validations
            if (isNaN(lbs) || lbs < 40 || lbs > 800 || isNaN(ft) || ft < 2 || ft > 9 || inches < 0 || inches >= 12) {
                showValidationError('Please enter realistic values: Weight 40-800 lbs, Height 2-9 ft, 0-11 in.');
                return;
            }

            weight = lbs;
            height = (ft * 12) + inches;
            bmi = (weight / (height * height)) * 703;
        }

        // Round to 1 decimal point safely
        bmi = Math.round(bmi * 10) / 10;
        
        // Update the Interface
        updateBMIUI(bmi);
    });

    function showValidationError(message) {
        if (window.showToast) {
            window.showToast(message);
        } else {
            alert(message);
        }
    }

    function updateBMIUI(bmi) {
        if (!bmiValueEl) return;
        
        // Count animation logic
        animateValue(bmiValueEl, parseFloat(bmiValueEl.innerText) || 0, bmi, 800);
        
        // Gauge Sweep mapping
        // Min: BMI 10, Max: BMI 40. Degree range: -135deg to 45deg (180deg total)
        const minBmi = 10;
        const maxBmi = 40;
        const clamped = Math.max(minBmi, Math.min(maxBmi, bmi));
        const rotation = -135 + ((clamped - minBmi) / (maxBmi - minBmi)) * 180;
        
        if (bmiGaugeFill) {
            bmiGaugeFill.style.transform = `rotate(${rotation}deg)`;
        }

        // Assessment Categories
        let category = '';
        let badgeColor = '';
        let tipText = '';
        let textColorClass = '';

        if (bmi < 18.5) {
            category = 'Underweight';
            badgeColor = '#17a2b8';
            textColorClass = 'text-info';
            tipText = 'Focus on nutrient-dense foods, lean protein, and heavy strength training. We recommend checking our Strength & Conditioning class to build muscle safely.';
        } else if (bmi >= 18.5 && bmi < 25) {
            category = 'Normal Weight';
            badgeColor = '#28a745';
            textColorClass = 'text-success';
            tipText = 'Outstanding! You are in a healthy range. Maintain your physique with a combination of regular cardio and resistance classes.';
        } else if (bmi >= 25 && bmi < 30) {
            category = 'Overweight';
            badgeColor = '#ffc107';
            textColorClass = 'text-warning';
            tipText = 'Incorporate consistent cardiovascular activity, calorie tracking, and high-intensity interval training. Try our Power HIIT classes to maximize fat burn.';
        } else {
            category = 'Obese';
            badgeColor = '#dc3545';
            textColorClass = 'text-danger';
            tipText = 'Prioritize cardiovascular consistency, nutrition guidance, and joint-friendly exercises. Consider booking a session with Marcus Vance for personalized coaching.';
        }

        if (bmiBadgeEl) {
            bmiBadgeEl.innerText = category;
            bmiBadgeEl.className = `badge bmi-badge ${textColorClass}`;
            bmiBadgeEl.style.borderColor = badgeColor;
            bmiBadgeEl.style.color = badgeColor;
        }

        if (bmiTipEl) {
            bmiTipEl.innerText = tipText;
        }
    }

    // Smooth value counter
    function animateValue(obj, start, end, duration) {
        let startTimestamp = null;
        const step = (timestamp) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
            obj.innerHTML = (progress * (end - start) + start).toFixed(1);
            if (progress < 1) {
                window.requestAnimationFrame(step);
            }
        };
        window.requestAnimationFrame(step);
    }
});
